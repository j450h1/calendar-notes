from  collections import namedtuple

from flask import Flask, request, abort, render_template
webapp = Flask(__name__)



@webapp.route('/', methods=['GET', 'POST'])
def index():
  return render_template("index.html")

if __name__ == '__main__':
  webapp.debug = True
  webapp.run()
