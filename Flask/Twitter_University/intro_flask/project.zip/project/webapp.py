import json

from flask import Flask, request, render_template

from flask.ext.sqlalchemy import SQLAlchemy
from sqlalchemy import Column, Integer, String

webapp = Flask(__name__)
webapp.config['SQLALCHEMY_DATABASE_URI'] = "sqlite:///database.db"
db = SQLAlchemy(webapp)

class Comment(db.Model):
  id = Column(Integer, primary_key=True)
  user = Column(String(50))
  comment = Column(String(120))

  def __init__(self, user, comment):
      self.user = user
      self.comment = comment

  def json(self):
    """Provide a method to convert un-serializable object to serializable representation."""
    return dict(id=self.id, user=self.user, comment=self.comment)

@webapp.route('/')
def hello_world():
  return render_template("base.html")
  

@webapp.route("/users/<user>")
def user(user):
  comments = Comment.query.filter_by(user=user)
  return render_template("user.html", comments=comments, user=user)
                         
@webapp.route("/users")
def users():
  comments = Comment.query.all()
  return render_template("users.html", comments=comments)


@webapp.route("/api/users/<user>")  
@webapp.route("/api/users")
def api_users(user=None):
  if user is None:
    return json.dumps([r.json() for r in Comment.query.all()])
  else:
    return json.dumps([r.json() for r in Comment.query.filter_by(user=user)])
    
if __name__ == '__main__':
  webapp.debug = True
  webapp.run()
