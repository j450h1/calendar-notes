from flask import Flask, request, abort, render_template
webapp = Flask('twitter.foobar.webapp')

data = [('Simeon', 'Franklin', '@sfranklin'),
        ('Travis', 'Carr', '@tmcarr'),
        ('Ethan', 'Song', '@songe')]


@webapp.route('/', methods=['GET', 'POST'])
def hello_world():
  username = 'anonymous'
  if request.method == 'POST':
    username = request.form.get('username', 'anonymous')
  return render_template('base.html', username=username)


@webapp.route('/users/')
@webapp.route('/users/<handle>')
def user(handle=None):
  # dashboard
  if handle is None:
    return render_template('users/index.html', data=data)
  # individual record
  matches = [row for row in data if handle == row[-1]]
  if matches:
    return render_template('users/index.html', data=matches)
  else:
    abort(404)
  
if __name__ == '__main__':
  webapp.debug = True
  webapp.run()
